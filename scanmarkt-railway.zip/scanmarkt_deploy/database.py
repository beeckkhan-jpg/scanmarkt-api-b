"""
database.py — Type-safe SQLite data layer for ScanMarkt
All table/column names are constants. No magic strings.
"""

import sqlite3
import os
from contextlib import contextmanager
from typing import Optional

# ── Table & column constants ─────────────────────────────────────────────────
T_USERS     = "users"
T_LISTS     = "shopping_lists"
T_ITEMS     = "list_items"
T_TEMPLATES = "templates"
T_BASKET    = "basket_sessions"

COL_ID         = "id"
COL_EMAIL      = "email"
COL_PASSWORD   = "password_hash"
COL_NAME       = "name"
COL_CREATED    = "created_at"
COL_USER_ID    = "user_id"
COL_LIST_ID    = "list_id"
COL_PRODUCT_ID = "product_id"
COL_QTY        = "quantity"
COL_STORE      = "store_id"
COL_PRICE      = "price"
COL_STATUS     = "status"
COL_TITLE      = "title"

DB_PATH: str = os.getenv("DATABASE_PATH", "scanmarkt.db")

# ── Schema ───────────────────────────────────────────────────────────────────
SCHEMA = f"""
CREATE TABLE IF NOT EXISTS {T_USERS} (
    {COL_ID}       INTEGER PRIMARY KEY AUTOINCREMENT,
    {COL_EMAIL}    TEXT    NOT NULL UNIQUE,
    {COL_PASSWORD} TEXT    NOT NULL,
    {COL_NAME}     TEXT    NOT NULL,
    {COL_CREATED}  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS {T_LISTS} (
    {COL_ID}      INTEGER PRIMARY KEY AUTOINCREMENT,
    {COL_USER_ID} INTEGER NOT NULL REFERENCES {T_USERS}({COL_ID}),
    {COL_TITLE}   TEXT    NOT NULL DEFAULT 'Meine Liste',
    {COL_STATUS}  TEXT    NOT NULL DEFAULT 'active'
                           CHECK({COL_STATUS} IN ('active','completed','archived')),
    {COL_CREATED} TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS {T_ITEMS} (
    {COL_ID}         INTEGER PRIMARY KEY AUTOINCREMENT,
    {COL_LIST_ID}    INTEGER NOT NULL REFERENCES {T_LISTS}({COL_ID}) ON DELETE CASCADE,
    {COL_PRODUCT_ID} TEXT    NOT NULL,
    {COL_NAME}       TEXT    NOT NULL,
    {COL_QTY}        INTEGER NOT NULL DEFAULT 1 CHECK({COL_QTY} > 0),
    icon             TEXT    NOT NULL DEFAULT '🛒',
    unit             TEXT    NOT NULL DEFAULT 'Stk'
);

CREATE TABLE IF NOT EXISTS {T_TEMPLATES} (
    {COL_ID}      INTEGER PRIMARY KEY AUTOINCREMENT,
    {COL_USER_ID} INTEGER NOT NULL REFERENCES {T_USERS}({COL_ID}),
    {COL_TITLE}   TEXT    NOT NULL,
    items_json    TEXT    NOT NULL DEFAULT '[]',
    {COL_CREATED} TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS {T_BASKET} (
    {COL_ID}         INTEGER PRIMARY KEY AUTOINCREMENT,
    {COL_USER_ID}    INTEGER NOT NULL REFERENCES {T_USERS}({COL_ID}),
    {COL_LIST_ID}    INTEGER REFERENCES {T_LISTS}({COL_ID}),
    {COL_PRODUCT_ID} TEXT    NOT NULL,
    {COL_NAME}       TEXT    NOT NULL,
    {COL_QTY}        INTEGER NOT NULL DEFAULT 1,
    {COL_PRICE}      REAL    NOT NULL,
    {COL_STORE}      TEXT    NOT NULL,
    {COL_CREATED}    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_lists_user   ON {T_LISTS}({COL_USER_ID});
CREATE INDEX IF NOT EXISTS idx_items_list   ON {T_ITEMS}({COL_LIST_ID});
CREATE INDEX IF NOT EXISTS idx_basket_user  ON {T_BASKET}({COL_USER_ID});
CREATE INDEX IF NOT EXISTS idx_tpl_user     ON {T_TEMPLATES}({COL_USER_ID});
"""


@contextmanager
def get_db():
    """Thread-safe connection with WAL mode and foreign keys enforced."""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    """Create tables if they don't exist. Safe to call on every startup."""
    with get_db() as conn:
        conn.executescript(SCHEMA)


def row_to_dict(row: Optional[sqlite3.Row]) -> Optional[dict]:
    if row is None:
        return None
    return dict(row)


def rows_to_list(rows) -> list[dict]:
    return [dict(r) for r in rows]
