"""
price_scraper.py
─────────────────
Playwright-based price scrapers for German supermarkets.
Covers: REWE (official API), Lidl (web), Penny (web).

Architecture:
  - Each scraper returns a PriceResult or None.
  - All scrapers share a single browser instance per session.
  - Anti-bot: random delay, realistic headers, no-js fallback.

Usage:
    from price_scraper import PriceScraper
    with PriceScraper() as scraper:
        prices = scraper.get_all_prices("Gouda Scheiben 200g")
"""

import re
import time
import random
import logging
import json
from dataclasses import dataclass, asdict
from typing import Optional
from playwright.sync_api import sync_playwright, Page, Browser, TimeoutError as PwTimeout

log = logging.getLogger("PriceScraper")

# ── Data model ─────────────────────────────────────────────────────────────
@dataclass
class PriceResult:
    store_id:       str
    store_name:     str
    product_name:   str
    price_eur:      float
    unit_price:     str        # e.g. "0,89 € / 100g"
    availability:   bool
    product_url:    str
    currency:       str = "EUR"

    def to_dict(self) -> dict:
        return asdict(self)


# ── Helpers ────────────────────────────────────────────────────────────────
def _random_delay(min_s=0.8, max_s=2.2):
    time.sleep(random.uniform(min_s, max_s))


def _parse_price(text: str) -> Optional[float]:
    """Extract float price from German price string like '1,79 €' or '1.79'."""
    if not text:
        return None
    cleaned = re.sub(r"[^\d,\.]", "", text.strip())
    # German format: comma decimal
    cleaned = cleaned.replace(".", "").replace(",", ".")
    try:
        val = float(cleaned)
        return val if 0.01 < val < 500 else None
    except ValueError:
        return None


def _stealth_page(browser: Browser) -> Page:
    """Create a page with realistic browser fingerprint."""
    ctx = browser.new_context(
        viewport={"width": 1366, "height": 768},
        user_agent=(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        locale="de-DE",
        timezone_id="Europe/Berlin",
        extra_http_headers={
            "Accept-Language": "de-DE,de;q=0.9,en;q=0.8",
        },
    )
    page = ctx.new_page()
    # Hide automation signals
    page.add_init_script("""
        Object.defineProperty(navigator, 'webdriver', {get: () => false});
        Object.defineProperty(navigator, 'languages', {get: () => ['de-DE', 'de']});
    """)
    return page


# ══════════════════════════════════════════════════════════════════════════
# REWE — uses their internal search API (JSON, very stable)
# ══════════════════════════════════════════════════════════════════════════
def _scrape_rewe(page: Page, query: str) -> Optional[PriceResult]:
    """
    REWE has a discoverable JSON API used by their web shop.
    No JS rendering needed — direct API call via page.evaluate.
    """
    try:
        url = (
            f"https://shop.rewe.de/api/products"
            f"?search={query.replace(' ', '+')}"
            f"&market=&objectsPerPage=5&page=1"
        )
        page.goto(url, wait_until="domcontentloaded", timeout=12000)
        _random_delay(0.5, 1.0)

        content = page.content()
        # Extract JSON from page body
        match = re.search(r'\{.*"products".*\}', content, re.DOTALL)
        if not match:
            # Try direct JSON
            try:
                data = json.loads(page.inner_text("body"))
            except Exception:
                log.warning("REWE: no JSON found")
                return None
        else:
            data = json.loads(match.group())

        products = data.get("products", {})
        if isinstance(products, dict):
            items = products.get("products", [])
        elif isinstance(products, list):
            items = products
        else:
            items = []

        if not items:
            log.warning("REWE: no products for '%s'", query)
            return None

        item = items[0]
        name = item.get("name", query)

        # Price extraction — REWE uses cents or float
        pricing = item.get("pricing", {})
        price_raw = pricing.get("currentRetailPrice") or pricing.get("price")
        if price_raw is None:
            price_raw = item.get("price")

        price = None
        if isinstance(price_raw, (int, float)):
            price = float(price_raw) / 100 if price_raw > 100 else float(price_raw)
        elif isinstance(price_raw, str):
            price = _parse_price(price_raw)

        if not price:
            log.warning("REWE: could not extract price for '%s'", query)
            return None

        unit_info = pricing.get("quantityAndUnit", "")
        product_id = item.get("id") or item.get("sku", "")

        return PriceResult(
            store_id     = "rewe",
            store_name   = "REWE",
            product_name = name,
            price_eur    = round(price, 2),
            unit_price   = unit_info,
            availability = item.get("available", True),
            product_url  = f"https://shop.rewe.de/p/{product_id}" if product_id else "https://shop.rewe.de",
        )

    except PwTimeout:
        log.warning("REWE: timeout")
        return None
    except Exception as e:
        log.error("REWE: %s", e)
        return None


# ══════════════════════════════════════════════════════════════════════════
# LIDL — parses their web shop search results
# ══════════════════════════════════════════════════════════════════════════
def _scrape_lidl(page: Page, query: str) -> Optional[PriceResult]:
    """
    Lidl.de renders product cards in JS. We wait for price elements.
    """
    try:
        url = f"https://www.lidl.de/q/{query.replace(' ', '+')}"
        page.goto(url, wait_until="domcontentloaded", timeout=15000)
        _random_delay(1.5, 2.5)

        # Accept cookies if banner appears
        try:
            page.click("[data-testid='cookie-accept-button']", timeout=3000)
            _random_delay(0.5, 1.0)
        except PwTimeout:
            pass

        # Wait for product grid
        try:
            page.wait_for_selector(
                ".s-grid__item, .product-grid-box, [data-cy='product-card']",
                timeout=8000
            )
        except PwTimeout:
            log.warning("Lidl: product grid did not load for '%s'", query)
            return None

        # Extract first product
        price_el = page.query_selector(
            ".price-box__price, .m-price__price, .product-price, [data-cy='product-price']"
        )
        name_el = page.query_selector(
            ".s-title, .product-item__title, [data-cy='product-name'], .m-title"
        )
        link_el = page.query_selector("a.s-grid__item, a.product-grid-box, [data-cy='product-card'] a")

        price_text = price_el.inner_text() if price_el else ""
        price = _parse_price(price_text)

        if not price:
            log.warning("Lidl: no price found for '%s'", query)
            return None

        name = name_el.inner_text().strip() if name_el else query
        href = link_el.get_attribute("href") if link_el else ""
        product_url = f"https://www.lidl.de{href}" if href and href.startswith("/") else href or "https://www.lidl.de"

        return PriceResult(
            store_id     = "lidl",
            store_name   = "Lidl",
            product_name = name[:100],
            price_eur    = round(price, 2),
            unit_price   = "",
            availability = True,
            product_url  = product_url,
        )

    except PwTimeout:
        log.warning("Lidl: timeout")
        return None
    except Exception as e:
        log.error("Lidl: %s", e)
        return None


# ══════════════════════════════════════════════════════════════════════════
# PENNY — similar to Lidl
# ══════════════════════════════════════════════════════════════════════════
def _scrape_penny(page: Page, query: str) -> Optional[PriceResult]:
    try:
        url = f"https://www.penny.de/suche?search={query.replace(' ', '+')}"
        page.goto(url, wait_until="domcontentloaded", timeout=15000)
        _random_delay(1.0, 2.0)

        try:
            page.click("#onetrust-accept-btn-handler, [data-testid='accept-cookies']", timeout=3000)
            _random_delay(0.5, 1.0)
        except PwTimeout:
            pass

        try:
            page.wait_for_selector(".product-tile, .js-product-tile", timeout=8000)
        except PwTimeout:
            log.warning("Penny: no product tiles for '%s'", query)
            return None

        price_el = page.query_selector(".product-tile__price, .js-price, .price")
        name_el  = page.query_selector(".product-tile__title, .product-name, h3.title")

        price_text = price_el.inner_text() if price_el else ""
        price = _parse_price(price_text)
        if not price:
            log.warning("Penny: no price for '%s'", query)
            return None

        name = name_el.inner_text().strip() if name_el else query

        return PriceResult(
            store_id     = "penny",
            store_name   = "Penny",
            product_name = name[:100],
            price_eur    = round(price, 2),
            unit_price   = "",
            availability = True,
            product_url  = f"https://www.penny.de/suche?search={query.replace(' ', '+')}",
        )

    except PwTimeout:
        log.warning("Penny: timeout")
        return None
    except Exception as e:
        log.error("Penny: %s", e)
        return None


# ══════════════════════════════════════════════════════════════════════════
# MAIN SCRAPER CLASS
# ══════════════════════════════════════════════════════════════════════════
class PriceScraper:
    """
    Context-manager that manages a single Playwright browser session.

    Usage:
        with PriceScraper() as scraper:
            results = scraper.get_all_prices("Gouda Scheiben")
    """

    def __init__(self, headless: bool = True):
        self.headless = headless
        self._pw      = None
        self._browser = None

    def __enter__(self):
        self._pw      = sync_playwright().start()
        self._browser = self._pw.chromium.launch(
            headless=self.headless,
            args=[
                "--no-sandbox",
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
            ],
        )
        log.info("Browser launched")
        return self

    def __exit__(self, *_):
        if self._browser:
            self._browser.close()
        if self._pw:
            self._pw.stop()
        log.info("Browser closed")

    def _new_page(self) -> Page:
        return _stealth_page(self._browser)

    def get_rewe_price(self, query: str) -> Optional[PriceResult]:
        page = self._new_page()
        try:
            return _scrape_rewe(page, query)
        finally:
            page.context.close()

    def get_lidl_price(self, query: str) -> Optional[PriceResult]:
        page = self._new_page()
        try:
            return _scrape_lidl(page, query)
        finally:
            page.context.close()

    def get_penny_price(self, query: str) -> Optional[PriceResult]:
        page = self._new_page()
        try:
            return _scrape_penny(page, query)
        finally:
            page.context.close()

    def get_all_prices(self, query: str) -> list[PriceResult]:
        """
        Query all scrapers for a product.
        Returns list sorted cheapest → most expensive.
        """
        scrapers = [
            ("rewe",  self.get_rewe_price),
            ("lidl",  self.get_lidl_price),
            ("penny", self.get_penny_price),
        ]
        results = []
        for store_id, fn in scrapers:
            log.info("Scraping %s for '%s'…", store_id, query)
            result = fn(query)
            if result:
                results.append(result)
            _random_delay(0.5, 1.2)

        results.sort(key=lambda r: r.price_eur)
        return results


# ── Self-test ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import json
    logging.basicConfig(level=logging.INFO)

    QUERY = "Gouda Scheiben"
    print(f"\n{'─'*54}")
    print(f"TEST › Fiyat karşılaştırma: '{QUERY}'")
    print("─"*54)

    with PriceScraper(headless=True) as scraper:
        # Test REWE only first (fastest, API-based)
        print("\n  [1/1] REWE API testi…")
        r = scraper.get_rewe_price(QUERY)
        if r:
            print(f"  ✅ {r.store_name}: {r.price_eur:.2f} € — {r.product_name}")
        else:
            print("  ⚠️  REWE: Sonuç yok (ağ kısıtlaması olabilir)")

    print("\n" + "─"*54)
    print("TEST TAMAMLANDI")
