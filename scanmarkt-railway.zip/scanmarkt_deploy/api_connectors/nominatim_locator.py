"""
nominatim_locator.py — OSM Overpass + Nominatim
Railway'de gerçek API çağrısı yapılır. Erişilemezse mock konum döner.
"""

import requests, math, logging, urllib.parse, time
from dataclasses import dataclass, asdict
from typing import Optional

log = logging.getLogger("Nominatim")

OVERPASS_URL  = "https://overpass-api.de/api/interpreter"
NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
HEADERS       = {"User-Agent": "ScanMarkt/1.0 (railway; contact@scanmarkt.de)"}

STORE_OSM_NAMES = {
    "aldi":     ["Aldi", "Aldi Süd", "Aldi Nord"],
    "lidl":     ["Lidl"],
    "rewe":     ["REWE", "Rewe"],
    "kaufland": ["Kaufland"],
    "netto":    ["Netto"],
    "penny":    ["Penny"],
    "edeka":    ["Edeka", "EDEKA"],
}

# Mock locations — her şehir için kabaca doğru koordinatlar
MOCK_STORES = {
    "aldi":     {"name":"Aldi Süd",  "address":"Musterstraße 1",  "lat_off":0.008, "lon_off":0.005},
    "lidl":     {"name":"Lidl",      "address":"Hauptstraße 23",  "lat_off":0.003, "lon_off":0.010},
    "rewe":     {"name":"REWE",      "address":"Bahnhofstr. 12",  "lat_off":0.006, "lon_off":-0.004},
    "kaufland": {"name":"Kaufland",  "address":"Ringstraße 45",   "lat_off":-0.005,"lon_off":0.008},
    "netto":    {"name":"Netto",     "address":"Schulstraße 7",   "lat_off":0.002, "lon_off":-0.009},
    "penny":    {"name":"Penny",     "address":"Gartenweg 3",     "lat_off":-0.003,"lon_off":0.003},
}

@dataclass
class StoreLocation:
    store_id:    str
    name:        str
    address:     str
    lat:         float
    lon:         float
    distance_km: float
    maps_url:    str

    def to_dict(self): return asdict(self)


def _haversine(lat1, lon1, lat2, lon2):
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2-lat1), math.radians(lon2-lon1)
    a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))


def _maps_url(name, lat, lon):
    q = urllib.parse.quote(name)
    return f"https://www.google.com/maps/search/{q}/@{lat},{lon},15z"


def _mock_stores(lat, lon, store_ids):
    result = {}
    for sid in store_ids:
        m = MOCK_STORES.get(sid)
        if not m:
            continue
        slat = lat + m["lat_off"]
        slon = lon + m["lon_off"]
        dist = _haversine(lat, lon, slat, slon)
        result[sid] = [StoreLocation(
            store_id=sid, name=m["name"], address=m["address"],
            lat=round(slat,6), lon=round(slon,6),
            distance_km=round(dist,2),
            maps_url=_maps_url(m["name"], slat, slon),
        )]
    return result


def find_nearest_stores(lat, lon, store_ids=None, radius_m=3000, limit=1):
    target = list(store_ids or STORE_OSM_NAMES.keys())

    # 1. Overpass dene
    query = f"[out:json][timeout:10];(node[\"shop\"=\"supermarket\"](around:{radius_m},{lat},{lon});node[\"shop\"=\"discount_supermarket\"](around:{radius_m},{lat},{lon}););out body;"
    found = {sid: [] for sid in target}

    try:
        r = requests.post(
            OVERPASS_URL,
            data={"data": query},
            headers=HEADERS,
            timeout=12
        )
        if r.status_code == 200:
            for el in r.json().get("elements", []):
                tags = el.get("tags", {})
                name = tags.get("name", "")
                if not name:
                    continue
                nl = name.lower()
                sid = next((s for s, patterns in STORE_OSM_NAMES.items()
                            if any(p.lower() in nl for p in patterns)), None)
                if not sid or sid not in target:
                    continue
                elat, elon = float(el.get("lat",0)), float(el.get("lon",0))
                dist = _haversine(lat, lon, elat, elon)
                addr_parts = [tags.get("addr:street",""), tags.get("addr:housenumber",""),
                              tags.get("addr:postcode",""), tags.get("addr:city","")]
                addr = " ".join(p for p in addr_parts if p) or "Adres yok"
                found[sid].append(StoreLocation(
                    store_id=sid, name=name, address=addr,
                    lat=elat, lon=elon, distance_km=round(dist,2),
                    maps_url=_maps_url(name, elat, elon),
                ))
            for sid in found:
                found[sid].sort(key=lambda s: s.distance_km)
                found[sid] = found[sid][:limit]

            # Eksik olanlar için mock kullan
            missing = [sid for sid in target if not found[sid]]
            if missing:
                mock = _mock_stores(lat, lon, missing)
                for sid, locs in mock.items():
                    found[sid] = locs
            return found
    except Exception as e:
        log.warning("Overpass hatası: %s — mock kullanılıyor", e)

    # 2. Tam mock fallback
    return _mock_stores(lat, lon, target)


def nearest_store(lat, lon, store_id) -> Optional[StoreLocation]:
    result = find_nearest_stores(lat, lon, store_ids=[store_id], limit=1)
    locs = result.get(store_id, [])
    return locs[0] if locs else None
