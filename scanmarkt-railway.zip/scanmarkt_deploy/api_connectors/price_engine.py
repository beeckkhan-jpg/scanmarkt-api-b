"""
price_engine.py
───────────────
Central price comparison engine for ScanMarkt.
Orchestrates: cache → scrapers → mock fallback.

Flask backend calls this directly via:
    from api_connectors.price_engine import get_prices_for_product

The mock fallback ensures the app always shows prices
even when scrapers are blocked or network is unavailable.
"""

import hashlib
import logging
import os
from typing import Optional
from dataclasses import dataclass, asdict

from .price_cache import get_cached, set_cached, clear_expired, cache_stats

log = logging.getLogger("PriceEngine")

# ── Data model ─────────────────────────────────────────────────────────────
@dataclass
class StorePrice:
    store_id:    str
    store_name:  str
    price_eur:   float
    unit_price:  str
    available:   bool
    product_url: str
    from_cache:  bool = False
    is_mock:     bool = False

    def to_dict(self) -> dict:
        return asdict(self)


STORE_NAMES = {
    "aldi":     "Aldi Süd",
    "lidl":     "Lidl",
    "rewe":     "REWE",
    "kaufland": "Kaufland",
    "netto":    "Netto",
    "penny":    "Penny",
}

# Scraping enabled flag — set False to always use mock (e.g. in CI/tests)
SCRAPING_ENABLED = os.getenv("SCRAPING_ENABLED", "true").lower() == "true"


# ── Mock price generator ───────────────────────────────────────────────────
def _mock_price(product_name: str, store_id: str) -> float:
    """
    Deterministic mock price based on product+store hash.
    Ensures same product always shows same relative prices across stores.
    Cheaper stores (aldi, lidl, netto) get lower base prices.
    """
    key      = f"{product_name.lower()}:{store_id}"
    digest   = int(hashlib.md5(key.encode()).hexdigest()[:8], 16)
    base     = 0.49 + (len(product_name) % 20) * 0.18
    variance = (digest % 100) / 100 * 0.60 - 0.30

    # Discount stores are cheaper on average
    discount_bonus = {
        "aldi": -0.20, "lidl": -0.15, "netto": -0.12,
        "penny": -0.05, "rewe": 0.10, "kaufland": 0.05,
    }
    bonus = discount_bonus.get(store_id, 0)
    return max(0.29, round(base + variance + bonus, 2))


def _mock_store_prices(product_name: str, store_ids: list[str]) -> list[StorePrice]:
    """Generate mock prices for all requested stores."""
    results = []
    for sid in store_ids:
        price = _mock_price(product_name, sid)
        results.append(StorePrice(
            store_id    = sid,
            store_name  = STORE_NAMES.get(sid, sid.title()),
            price_eur   = price,
            unit_price  = "",
            available   = True,
            product_url = f"https://www.{sid}.de",
            is_mock     = True,
        ))
    return sorted(results, key=lambda s: s.price_eur)


# ── Live scraper wrapper ───────────────────────────────────────────────────
def _scrape_live(product_name: str, store_ids: list[str]) -> list[StorePrice]:
    """
    Try live scraping. Falls back to mock for any store that fails.
    """
    try:
        from .price_scraper import PriceScraper
    except ImportError:
        log.warning("price_scraper not available — using mock")
        return []

    results = []
    scraped_ids = set()

    # Only scrape stores we have scrapers for
    scrapeable = {"rewe", "lidl", "penny"}
    to_scrape  = [sid for sid in store_ids if sid in scrapeable]

    if not to_scrape:
        return []

    try:
        with PriceScraper(headless=True) as scraper:
            for sid in to_scrape:
                cached = get_cached(product_name, sid)
                if cached:
                    results.append(StorePrice(from_cache=True, is_mock=False, **cached))
                    scraped_ids.add(sid)
                    continue

                fn_map = {
                    "rewe":  scraper.get_rewe_price,
                    "lidl":  scraper.get_lidl_price,
                    "penny": scraper.get_penny_price,
                }
                fn = fn_map.get(sid)
                if not fn:
                    continue

                pr = fn(product_name)
                if pr:
                    sp = StorePrice(
                        store_id    = pr.store_id,
                        store_name  = pr.store_name,
                        price_eur   = pr.price_eur,
                        unit_price  = pr.unit_price,
                        available   = pr.availability,
                        product_url = pr.product_url,
                    )
                    set_cached(product_name, sid, sp.to_dict())
                    results.append(sp)
                    scraped_ids.add(sid)

    except Exception as e:
        log.error("Scraper error: %s", e)

    return results


# ── Public API ─────────────────────────────────────────────────────────────
def get_prices_for_product(
    product_name: str,
    store_ids:    list[str] | None = None,
    use_mock:     bool = False,
) -> list[StorePrice]:
    """
    Get prices for a product across all (or selected) stores.
    Order: cache → live scrape → mock.

    Args:
        product_name: Product name to search for
        store_ids:    Specific stores to query (None = all 6)
        use_mock:     Force mock data (useful for testing/demo)

    Returns:
        List of StorePrice sorted cheapest → most expensive.

    Example:
        prices = get_prices_for_product("Gouda Scheiben 200g")
        for p in prices:
            print(f"{p.store_name}: {p.price_eur:.2f} €")
    """
    target_stores = store_ids or list(STORE_NAMES.keys())
    clear_expired()   # housekeeping

    if use_mock or not SCRAPING_ENABLED:
        log.info("Using mock prices for '%s'", product_name)
        return _mock_store_prices(product_name, target_stores)

    # Try live scraping
    live_results   = _scrape_live(product_name, target_stores)
    scraped_ids    = {r.store_id for r in live_results}
    missing_stores = [sid for sid in target_stores if sid not in scraped_ids]

    # Fill missing with mock
    if missing_stores:
        log.info(
            "Mock fallback for %d stores: %s",
            len(missing_stores), missing_stores
        )
        mock_results = _mock_store_prices(product_name, missing_stores)
        live_results.extend(mock_results)

    return sorted(live_results, key=lambda s: s.price_eur)


def compare_list_prices(
    shopping_list: list[dict],
    store_ids:     list[str] | None = None,
    use_mock:      bool = False,
) -> dict:
    """
    Compare total basket cost across stores for a full shopping list.

    Args:
        shopping_list: [{"name": "Gouda Scheiben", "qty": 2}, ...]
        store_ids:     Stores to compare

    Returns:
        {
          "store_totals": {"aldi": 12.40, "lidl": 11.90, ...},
          "cheapest":     "lidl",
          "savings":      0.50,
          "items":        {product_name: {store_id: price, ...}, ...}
        }
    """
    target_stores = store_ids or list(STORE_NAMES.keys())
    store_totals: dict[str, float] = {sid: 0.0 for sid in target_stores}
    items_detail: dict[str, dict] = {}

    for item in shopping_list:
        name = item.get("name", "")
        qty  = int(item.get("qty", 1))
        if not name:
            continue

        prices = get_prices_for_product(name, target_stores, use_mock=use_mock)
        item_prices: dict[str, float] = {}

        for sp in prices:
            item_prices[sp.store_id] = sp.price_eur
            store_totals[sp.store_id] = round(
                store_totals.get(sp.store_id, 0) + sp.price_eur * qty, 2
            )

        items_detail[name] = {"qty": qty, "prices": item_prices}

    # Find cheapest store
    valid_totals = {k: v for k, v in store_totals.items() if v > 0}
    if not valid_totals:
        return {"error": "No prices found"}

    cheapest = min(valid_totals, key=valid_totals.get)
    most_exp = max(valid_totals, key=valid_totals.get)
    savings  = round(valid_totals[most_exp] - valid_totals[cheapest], 2)

    return {
        "store_totals": {
            sid: {
                "total_eur":  round(v, 2),
                "store_name": STORE_NAMES.get(sid, sid),
            }
            for sid, v in sorted(valid_totals.items(), key=lambda x: x[1])
        },
        "cheapest":         cheapest,
        "cheapest_name":    STORE_NAMES.get(cheapest, cheapest),
        "cheapest_total":   valid_totals[cheapest],
        "most_expensive":   most_exp,
        "savings_vs_worst": savings,
        "items":            items_detail,
    }
