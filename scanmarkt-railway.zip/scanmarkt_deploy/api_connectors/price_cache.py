"""
price_cache.py
──────────────
SQLite-backed cache for scraped prices.
Prevents hammering supermarket sites on every request.
TTL: 6 hours (prices don't change faster than that).

Used by price_engine.py automatically.
"""

import sqlite3
import json
import time
import os
import logging
from typing import Optional
from contextlib import contextmanager

log = logging.getLogger("PriceCache")

CACHE_DB  = os.getenv("PRICE_CACHE_DB", "/tmp/scanmarkt_price_cache.db")
TTL_SECS  = 6 * 3600   # 6 hours

SCHEMA = """
CREATE TABLE IF NOT EXISTS price_cache (
    query      TEXT NOT NULL,
    store_id   TEXT NOT NULL,
    data_json  TEXT NOT NULL,
    cached_at  REAL NOT NULL,
    PRIMARY KEY (query, store_id)
);
CREATE INDEX IF NOT EXISTS idx_cache_query ON price_cache(query);
"""


@contextmanager
def _db():
    conn = sqlite3.connect(CACHE_DB)
    conn.row_factory = sqlite3.Row
    try:
        conn.executescript(SCHEMA)
        yield conn
        conn.commit()
    finally:
        conn.close()


def get_cached(query: str, store_id: str) -> Optional[dict]:
    """Return cached price dict if fresh, else None."""
    with _db() as conn:
        row = conn.execute(
            "SELECT data_json, cached_at FROM price_cache WHERE query=? AND store_id=?",
            (query.lower(), store_id)
        ).fetchone()
        if not row:
            return None
        age = time.time() - row["cached_at"]
        if age > TTL_SECS:
            log.debug("Cache expired (%.0f min) for %s/%s", age/60, query, store_id)
            return None
        log.debug("Cache HIT: %s/%s (%.0f min old)", query, store_id, age/60)
        return json.loads(row["data_json"])


def set_cached(query: str, store_id: str, data: dict) -> None:
    """Store price data in cache."""
    with _db() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO price_cache
               (query, store_id, data_json, cached_at)
               VALUES (?, ?, ?, ?)""",
            (query.lower(), store_id, json.dumps(data, ensure_ascii=False), time.time())
        )
    log.debug("Cache SET: %s/%s", query, store_id)


def clear_expired() -> int:
    """Remove entries older than TTL. Returns number deleted."""
    cutoff = time.time() - TTL_SECS
    with _db() as conn:
        cur = conn.execute("DELETE FROM price_cache WHERE cached_at < ?", (cutoff,))
        n = cur.rowcount
    if n:
        log.info("Cache: removed %d expired entries", n)
    return n


def cache_stats() -> dict:
    """Return cache statistics."""
    with _db() as conn:
        total   = conn.execute("SELECT COUNT(*) FROM price_cache").fetchone()[0]
        fresh   = conn.execute(
            "SELECT COUNT(*) FROM price_cache WHERE cached_at > ?",
            (time.time() - TTL_SECS,)
        ).fetchone()[0]
    return {"total": total, "fresh": fresh, "expired": total - fresh, "ttl_hours": TTL_SECS//3600}
