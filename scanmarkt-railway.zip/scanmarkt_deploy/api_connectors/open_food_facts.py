"""
open_food_facts.py — Open Food Facts API connector
Railway'de dış ağa erişim açık, bu yüzden gerçek API çağrısı yapılır.
Barkod yoksa mock veri döner (uygulama hiç çökmez).
"""

import requests, logging, time
from dataclasses import dataclass, asdict
from typing import Optional

log = logging.getLogger("OFF")

BASE      = "https://world.openfoodfacts.org"
FIELDS    = "code,product_name,product_name_de,brands,categories,quantity,image_front_url,nutriscore_grade,stores"
HEADERS   = {"User-Agent": "ScanMarkt/1.0 (railway; contact@scanmarkt.de)"}

# ── Mock product bank — her zaman çalışır ──────────────────────────────────
MOCK_PRODUCTS = {
    "4000417025005": {"name":"Gouda Scheiben",     "brand":"Milbona",  "cat":"Käse",    "qty":"200g"},
    "4005500015003": {"name":"Mozzarella Kugeln",  "brand":"Galbani",  "cat":"Käse",    "qty":"125g"},
    "4003736003005": {"name":"Vollmilch 3,5%",     "brand":"Weihenstephan","cat":"Milch","qty":"1 L"},
    "4100930076001": {"name":"Weißbrot",            "brand":"Harry",    "cat":"Brot",    "qty":"500g"},
    "4008829003009": {"name":"Eier Freiland 10er", "brand":"Gut Bio",  "cat":"Eier",    "qty":"10 Stk"},
    "4011200296908": {"name":"Bananen",             "brand":"Chiquita", "cat":"Obst",    "qty":"1 kg"},
    "4316882002001": {"name":"Tomaten 500g",        "brand":"natürlich","cat":"Gemüse",  "qty":"500g"},
    "4008119002001": {"name":"Spaghetti No.5",      "brand":"Barilla",  "cat":"Pasta",   "qty":"500g"},
    "4003020001003": {"name":"Butter 82% Fett",     "brand":"Kerrygold","cat":"Molkerei","qty":"250g"},
    "4014681001002": {"name":"Basmati Reis",        "brand":"Uncle Ben","cat":"Reis",    "qty":"1 kg"},
}

@dataclass
class Product:
    barcode:    str
    name:       str
    brand:      str
    category:   str
    quantity:   str
    image_url:  str
    nutriscore: str
    stores:     str
    source:     str = "open_food_facts"

    def to_dict(self): return asdict(self)


def _mock(barcode: str) -> Optional[Product]:
    m = MOCK_PRODUCTS.get(barcode)
    if not m:
        return None
    return Product(barcode=barcode, name=m["name"], brand=m["brand"],
                   category=m["cat"], quantity=m["qty"],
                   image_url="", nutriscore="", stores="", source="mock")


def lookup_barcode(barcode: str) -> Optional[Product]:
    barcode = barcode.strip()
    # 1. Gerçek API dene
    try:
        r = requests.get(
            f"{BASE}/api/v2/product/{barcode}",
            params={"fields": FIELDS},
            headers=HEADERS, timeout=8
        )
        if r.status_code == 200:
            d = r.json()
            if d.get("status") == 1:
                raw = d["product"]
                name = (raw.get("product_name_de") or raw.get("product_name") or "").strip()
                if name:
                    return Product(
                        barcode    = barcode,
                        name       = name,
                        brand      = raw.get("brands","").split(",")[0].strip(),
                        category   = raw.get("categories","").split(",")[0].strip(),
                        quantity   = raw.get("quantity",""),
                        image_url  = raw.get("image_front_url",""),
                        nutriscore = (raw.get("nutriscore_grade") or "").upper(),
                        stores     = raw.get("stores",""),
                    )
    except Exception as e:
        log.warning("OFF API ulaşılamadı: %s — mock kullanılıyor", e)

    # 2. Mock'a düş
    return _mock(barcode)


def search_products(query: str, limit: int = 10) -> list[Product]:
    # 1. Gerçek API
    try:
        r = requests.get(
            f"{BASE}/cgi/search.pl",
            params={"search_terms": query, "search_simple": 1,
                    "action": "process", "json": 1,
                    "page_size": limit, "fields": FIELDS,
                    "tagtype_0":"countries","tag_contains_0":"contains","tag_0":"germany"},
            headers=HEADERS, timeout=8
        )
        if r.status_code == 200:
            products = []
            for raw in r.json().get("products", []):
                name = (raw.get("product_name_de") or raw.get("product_name") or "").strip()
                if not name:
                    continue
                products.append(Product(
                    barcode    = str(raw.get("code","")),
                    name       = name,
                    brand      = raw.get("brands","").split(",")[0].strip(),
                    category   = raw.get("categories","").split(",")[0].strip(),
                    quantity   = raw.get("quantity",""),
                    image_url  = raw.get("image_front_url",""),
                    nutriscore = (raw.get("nutriscore_grade") or "").upper(),
                    stores     = raw.get("stores",""),
                ))
            if products:
                return products[:limit]
    except Exception as e:
        log.warning("OFF arama hatası: %s — mock kullanılıyor", e)

    # 2. Mock fallback — query ile eşleşen mock ürünleri döndür
    q = query.lower()
    results = []
    for bc, m in MOCK_PRODUCTS.items():
        if q in m["name"].lower() or q in m["cat"].lower():
            results.append(Product(barcode=bc, name=m["name"], brand=m["brand"],
                                   category=m["cat"], quantity=m["qty"],
                                   image_url="", nutriscore="", stores="", source="mock"))
    return results[:limit]
