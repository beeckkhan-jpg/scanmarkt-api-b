"""
api_connectors — ScanMarkt external API integrations
"""
from .open_food_facts import lookup_barcode, search_products
from .nominatim_locator import find_nearest_stores, nearest_store
from .price_engine import get_prices_for_product, compare_list_prices

__all__ = [
    "lookup_barcode",
    "search_products",
    "find_nearest_stores",
    "nearest_store",
    "get_prices_for_product",
    "compare_list_prices",
]
