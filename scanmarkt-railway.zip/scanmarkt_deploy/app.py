"""
app.py — ScanMarkt Backend API
Production-ready: input validation, typed DB layer, structured errors, env secrets.

Endpoints:
  POST /api/kayit          — Register
  POST /api/giris          — Login
  GET  /api/profil         — My profile (auth)
  POST /api/liste          — Create shopping list (auth)
  GET  /api/liste          — Get my lists (auth)
  POST /api/liste/<id>/urun — Add item to list (auth)
  GET  /api/liste/<id>/urun — Get items of a list (auth)
  POST /api/sepet          — Add basket item (auth)
  GET  /api/sepet          — Get my basket (auth)
  POST /api/sablon         — Save template (auth)
  GET  /api/sablon         — Get my templates (auth)
  GET  /api/saglik         — Health check (public)
"""

import os
import json
from dotenv import load_dotenv

# Load .env BEFORE importing auth (which reads JWT_SECRET from env)
load_dotenv()

from flask import Flask, request, jsonify
from database import (
    init_db, get_db, row_to_dict, rows_to_list,
    T_USERS, T_LISTS, T_ITEMS, T_TEMPLATES, T_BASKET,
    COL_ID, COL_EMAIL, COL_PASSWORD, COL_NAME, COL_USER_ID,
    COL_LIST_ID, COL_PRODUCT_ID, COL_QTY, COL_STORE,
    COL_PRICE, COL_STATUS, COL_TITLE, COL_CREATED,
)
from auth import hash_password, verify_password, create_token, require_auth
from schemas import (
    ValidationError,
    validate_register, validate_login,
    validate_create_list, validate_add_item,
    validate_basket_item, validate_save_template,
)

# ── App setup ─────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False


# ── Global error handlers ─────────────────────────────────────────────────────
@app.errorhandler(404)
def not_found(_):
    return jsonify({"error": "Bu uç nokta mevcut değil"}), 404

@app.errorhandler(405)
def method_not_allowed(_):
    return jsonify({"error": "Bu HTTP metodu desteklenmiyor"}), 405

@app.errorhandler(500)
def internal_error(e):
    return jsonify({"error": "Sunucu hatası", "detail": str(e)}), 500

def bad_request(msg: str, errors: dict = None):
    body = {"error": msg}
    if errors:
        body["errors"] = errors
    return jsonify(body), 400

def not_found_response(msg: str):
    return jsonify({"error": msg}), 404

def get_json_or_400():
    """Parse JSON body or return 400 if missing/malformed."""
    if not request.is_json:
        return None, (jsonify({"error": "Content-Type: application/json olmalı"}), 415)
    data = request.get_json(silent=True)
    if data is None:
        return None, (jsonify({"error": "Geçersiz JSON gövdesi"}), 400)
    return data, None


# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/api/saglik")
def health():
    """Health check — always returns 200 if server is up."""
    return jsonify({
        "status": "ok",
        "service": "ScanMarkt API",
        "version": "1.0.0",
    })


@app.post("/api/kayit")
def register():
    """
    POST /api/kayit
    Body: { name, email, password }
    Returns: { user, token }
    """
    data, err = get_json_or_400()
    if err:
        return err

    try:
        clean = validate_register(data)
    except ValidationError as e:
        return bad_request("Doğrulama hatası", e.errors)

    pw_hash = hash_password(clean["password"])

    try:
        with get_db() as conn:
            # Check duplicate
            existing = conn.execute(
                f"SELECT {COL_ID} FROM {T_USERS} WHERE {COL_EMAIL}=?",
                (clean["email"],)
            ).fetchone()
            if existing:
                return bad_request("Doğrulama hatası", {"email": "Bu e-posta zaten kayıtlı"})

            cur = conn.execute(
                f"INSERT INTO {T_USERS} ({COL_EMAIL},{COL_PASSWORD},{COL_NAME}) VALUES (?,?,?)",
                (clean["email"], pw_hash, clean["name"])
            )
            user_id = cur.lastrowid

    except Exception as e:
        return jsonify({"error": "Veritabanı hatası", "detail": str(e)}), 500

    token = create_token(user_id, clean["email"])
    return jsonify({
        "message": "Kayıt başarılı",
        "user": {
            "id":    user_id,
            "name":  clean["name"],
            "email": clean["email"],
        },
        "token": token,
    }), 201


@app.post("/api/giris")
def login():
    """
    POST /api/giris
    Body: { email, password }
    Returns: { user, token }
    """
    data, err = get_json_or_400()
    if err:
        return err

    try:
        clean = validate_login(data)
    except ValidationError as e:
        return bad_request("Doğrulama hatası", e.errors)

    with get_db() as conn:
        row = conn.execute(
            f"SELECT * FROM {T_USERS} WHERE {COL_EMAIL}=?",
            (clean["email"],)
        ).fetchone()

    if not row or not verify_password(clean["password"], row[COL_PASSWORD]):
        # Generic message — don't reveal whether email exists
        return jsonify({"error": "E-posta veya şifre hatalı"}), 401

    user = row_to_dict(row)
    token = create_token(user[COL_ID], user[COL_EMAIL])

    return jsonify({
        "message": "Giriş başarılı",
        "user": {
            "id":    user[COL_ID],
            "name":  user[COL_NAME],
            "email": user[COL_EMAIL],
        },
        "token": token,
    })


# ─────────────────────────────────────────────────────────────────────────────
# AUTH-PROTECTED ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/api/profil")
@require_auth
def get_profile():
    """GET /api/profil — Return current user info."""
    with get_db() as conn:
        row = conn.execute(
            f"SELECT {COL_ID},{COL_NAME},{COL_EMAIL},{COL_CREATED} FROM {T_USERS} WHERE {COL_ID}=?",
            (request.user_id,)
        ).fetchone()
    if not row:
        return not_found_response("Kullanıcı bulunamadı")
    return jsonify(row_to_dict(row))


# ── Shopping Lists ────────────────────────────────────────────────────────────

@app.post("/api/liste")
@require_auth
def create_list():
    """POST /api/liste — Create a new shopping list."""
    data, err = get_json_or_400()
    if err:
        return err
    try:
        clean = validate_create_list(data)
    except ValidationError as e:
        return bad_request("Doğrulama hatası", e.errors)

    with get_db() as conn:
        cur = conn.execute(
            f"INSERT INTO {T_LISTS} ({COL_USER_ID},{COL_TITLE}) VALUES (?,?)",
            (request.user_id, clean["title"])
        )
        list_id = cur.lastrowid
        row = conn.execute(
            f"SELECT * FROM {T_LISTS} WHERE {COL_ID}=?", (list_id,)
        ).fetchone()

    return jsonify({"message": "Liste oluşturuldu", "list": row_to_dict(row)}), 201


@app.get("/api/liste")
@require_auth
def get_lists():
    """GET /api/liste — Return all lists for current user."""
    with get_db() as conn:
        rows = conn.execute(
            f"SELECT * FROM {T_LISTS} WHERE {COL_USER_ID}=? ORDER BY {COL_CREATED} DESC",
            (request.user_id,)
        ).fetchall()
    return jsonify({"lists": rows_to_list(rows), "count": len(rows)})


@app.post("/api/liste/<int:list_id>/urun")
@require_auth
def add_item(list_id: int):
    """POST /api/liste/<id>/urun — Add a product to a shopping list."""
    # Verify list belongs to user
    with get_db() as conn:
        lst = conn.execute(
            f"SELECT {COL_ID} FROM {T_LISTS} WHERE {COL_ID}=? AND {COL_USER_ID}=?",
            (list_id, request.user_id)
        ).fetchone()
        if not lst:
            return not_found_response("Liste bulunamadı veya erişim izni yok")

    data, err = get_json_or_400()
    if err:
        return err
    try:
        clean = validate_add_item(data)
    except ValidationError as e:
        return bad_request("Doğrulama hatası", e.errors)

    with get_db() as conn:
        cur = conn.execute(
            f"INSERT INTO {T_ITEMS} ({COL_LIST_ID},{COL_PRODUCT_ID},{COL_NAME},{COL_QTY},icon,unit)"
            f" VALUES (?,?,?,?,?,?)",
            (list_id, clean["product_id"], clean["name"], clean["qty"], clean["icon"], clean["unit"])
        )
        row = conn.execute(
            f"SELECT * FROM {T_ITEMS} WHERE {COL_ID}=?", (cur.lastrowid,)
        ).fetchone()

    return jsonify({"message": "Ürün eklendi", "item": row_to_dict(row)}), 201


@app.get("/api/liste/<int:list_id>/urun")
@require_auth
def get_items(list_id: int):
    """GET /api/liste/<id>/urun — Get items of a list."""
    with get_db() as conn:
        lst = conn.execute(
            f"SELECT {COL_ID},{COL_TITLE},{COL_STATUS} FROM {T_LISTS}"
            f" WHERE {COL_ID}=? AND {COL_USER_ID}=?",
            (list_id, request.user_id)
        ).fetchone()
        if not lst:
            return not_found_response("Liste bulunamadı veya erişim izni yok")

        items = conn.execute(
            f"SELECT * FROM {T_ITEMS} WHERE {COL_LIST_ID}=?", (list_id,)
        ).fetchall()

    return jsonify({
        "list": row_to_dict(lst),
        "items": rows_to_list(items),
        "count": len(items),
    })


# ── Basket ────────────────────────────────────────────────────────────────────

@app.post("/api/sepet")
@require_auth
def add_to_basket():
    """POST /api/sepet — Record a scanned + bought item."""
    data, err = get_json_or_400()
    if err:
        return err
    try:
        clean = validate_basket_item(data)
    except ValidationError as e:
        return bad_request("Doğrulama hatası", e.errors)

    with get_db() as conn:
        cur = conn.execute(
            f"INSERT INTO {T_BASKET}"
            f" ({COL_USER_ID},{COL_LIST_ID},{COL_PRODUCT_ID},{COL_NAME},{COL_QTY},{COL_PRICE},{COL_STORE})"
            f" VALUES (?,?,?,?,?,?,?)",
            (request.user_id, clean["list_id"], clean["product_id"],
             clean["name"], clean["qty"], clean["price"], clean["store_id"])
        )
        row = conn.execute(
            f"SELECT * FROM {T_BASKET} WHERE {COL_ID}=?", (cur.lastrowid,)
        ).fetchone()

    return jsonify({"message": "Sepete eklendi", "item": row_to_dict(row)}), 201


@app.get("/api/sepet")
@require_auth
def get_basket():
    """GET /api/sepet — Get all basket items for current session."""
    with get_db() as conn:
        rows = conn.execute(
            f"SELECT * FROM {T_BASKET} WHERE {COL_USER_ID}=?"
            f" ORDER BY {COL_ID} DESC LIMIT 100",
            (request.user_id,)
        ).fetchall()
    items    = rows_to_list(rows)
    total    = round(sum(i["price"] * i["quantity"] for i in items), 2)
    return jsonify({
        "items":       items,
        "count":       len(items),
        "total_eur":   total,
    })


# ── Templates ─────────────────────────────────────────────────────────────────

@app.post("/api/sablon")
@require_auth
def save_template():
    """POST /api/sablon — Save a shopping list as a reusable template."""
    data, err = get_json_or_400()
    if err:
        return err
    try:
        clean = validate_save_template(data)
    except ValidationError as e:
        return bad_request("Doğrulama hatası", e.errors)

    with get_db() as conn:
        cur = conn.execute(
            f"INSERT INTO {T_TEMPLATES} ({COL_USER_ID},{COL_TITLE},items_json) VALUES (?,?,?)",
            (request.user_id, clean["title"], json.dumps(clean["items"], ensure_ascii=False))
        )
        row = conn.execute(
            f"SELECT * FROM {T_TEMPLATES} WHERE {COL_ID}=?", (cur.lastrowid,)
        ).fetchone()

    result = row_to_dict(row)
    result["items"] = json.loads(result["items_json"])
    del result["items_json"]
    return jsonify({"message": "Şablon kaydedildi", "template": result}), 201


@app.get("/api/sablon")
@require_auth
def get_templates():
    """GET /api/sablon — Return all saved templates."""
    with get_db() as conn:
        rows = conn.execute(
            f"SELECT * FROM {T_TEMPLATES} WHERE {COL_USER_ID}=? ORDER BY {COL_CREATED} DESC",
            (request.user_id,)
        ).fetchall()
    templates = []
    for r in rows:
        d = dict(r)
        d["items"] = json.loads(d["items_json"])
        del d["items_json"]
        templates.append(d)
    return jsonify({"templates": templates, "count": len(templates)})


# ─────────────────────────────────────────────────────────────────────────────
# EXTERNAL API ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/api/urun/barkod/<barcode>")
@require_auth
def barcode_lookup(barcode: str):
    """
    GET /api/urun/barkod/<barcode>
    Look up a product from Open Food Facts by barcode.
    Returns product name, brand, category, quantity, image.
    """
    if not barcode or not barcode.isdigit():
        return bad_request("Geçersiz barkod — yalnızca rakam içermeli")

    try:
        from api_connectors.open_food_facts import lookup_barcode
        product = lookup_barcode(barcode)
    except Exception as e:
        return jsonify({"error": "Ürün veritabanına erişilemedi", "detail": str(e)}), 503

    if not product:
        return jsonify({"error": f"Barkod bulunamadı: {barcode}", "barcode": barcode}), 404

    return jsonify({"product": product.to_dict()})


@app.get("/api/urun/ara")
@require_auth
def search_products_endpoint():
    """
    GET /api/urun/ara?q=Gouda&limit=10
    Search products by name using Open Food Facts.
    """
    q = request.args.get("q", "").strip()
    if not q or len(q) < 2:
        return bad_request("Arama terimi en az 2 karakter olmalı", {"q": "Çok kısa"})

    limit = min(int(request.args.get("limit", 10)), 30)

    try:
        from api_connectors.open_food_facts import search_products
        results = search_products(q, limit=limit)
    except Exception as e:
        return jsonify({"error": "Arama başarısız", "detail": str(e)}), 503

    return jsonify({
        "query":    q,
        "count":    len(results),
        "products": [p.to_dict() for p in results],
    })


@app.get("/api/fiyat")
@require_auth
def price_compare():
    """
    GET /api/fiyat?q=Gouda+Scheiben&stores=aldi,lidl,rewe
    Compare prices for a product across supermarkets.
    Uses cache (6h TTL) → scraper → mock fallback.
    """
    q = request.args.get("q", "").strip()
    if not q or len(q) < 2:
        return bad_request("Ürün adı gerekli", {"q": "Zorunlu parametre"})

    stores_param = request.args.get("stores", "")
    store_ids    = [s.strip() for s in stores_param.split(",") if s.strip()] or None

    try:
        from api_connectors.price_engine import get_prices_for_product
        prices = get_prices_for_product(q, store_ids=store_ids, use_mock=True)
    except Exception as e:
        return jsonify({"error": "Fiyat alınamadı", "detail": str(e)}), 503

    return jsonify({
        "query":    q,
        "count":    len(prices),
        "cheapest": prices[0].to_dict() if prices else None,
        "prices":   [p.to_dict() for p in prices],
    })


@app.post("/api/fiyat/liste")
@require_auth
def price_compare_list():
    """
    POST /api/fiyat/liste
    Body: {"items": [{"name": "Gouda Scheiben", "qty": 2}, ...]}
    Compare total basket cost across all stores.
    """
    data, err = get_json_or_400()
    if err:
        return err

    items = data.get("items", [])
    if not items or not isinstance(items, list):
        return bad_request("items listesi zorunlu ve boş olmamalı", {"items": "Gerekli"})
    if len(items) > 50:
        return bad_request("Maksimum 50 ürün karşılaştırılabilir")

    # Validate each item
    clean_items = []
    for i, item in enumerate(items):
        name = str(item.get("name", "")).strip()
        qty  = item.get("qty", 1)
        if not name:
            return bad_request(f"items[{i}].name boş olamaz")
        try:
            qty = max(1, int(qty))
        except (ValueError, TypeError):
            return bad_request(f"items[{i}].qty geçersiz")
        clean_items.append({"name": name, "qty": qty})

    try:
        from api_connectors.price_engine import compare_list_prices
        result = compare_list_prices(clean_items, use_mock=True)
    except Exception as e:
        return jsonify({"error": "Fiyat karşılaştırması başarısız", "detail": str(e)}), 503

    return jsonify(result)


@app.get("/api/market/yakın")
@require_auth
def find_nearby_stores():
    """
    GET /api/market/yakın?lat=48.135&lon=11.582&store=aldi&radius=2000
    Find nearest supermarkets using OpenStreetMap Overpass.
    """
    try:
        lat = float(request.args.get("lat", ""))
        lon = float(request.args.get("lon", ""))
    except (TypeError, ValueError):
        return bad_request("lat ve lon sayısal değer olmalı", {
            "lat": "Zorunlu", "lon": "Zorunlu"
        })

    if not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
        return bad_request("Geçersiz GPS koordinatı")

    store_param = request.args.get("store", "")
    store_ids   = [s.strip() for s in store_param.split(",") if s.strip()] or None

    try:
        radius = min(int(request.args.get("radius", 3000)), 10000)
    except ValueError:
        radius = 3000

    try:
        from api_connectors.nominatim_locator import find_nearest_stores
        stores = find_nearest_stores(lat, lon, store_ids=store_ids, radius_m=radius)
    except Exception as e:
        return jsonify({"error": "Konum servisi hatası", "detail": str(e)}), 503

    result = {}
    for sid, locations in stores.items():
        if locations:
            result[sid] = [loc.to_dict() for loc in locations]

    return jsonify({
        "lat":     lat,
        "lon":     lon,
        "radius":  radius,
        "found":   len(result),
        "stores":  result,
    })


# ── Entry point ───────────────────────────────────────────────────────────────
# Always init DB on startup (works on Railway, local, anywhere)
import sys as _sys
init_db()
print("✅ Veritabanı hazır")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"🚀 ScanMarkt API başlatılıyor → http://0.0.0.0:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)
