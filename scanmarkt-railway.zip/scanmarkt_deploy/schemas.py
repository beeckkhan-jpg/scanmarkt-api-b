"""
schemas.py — Input validation for every endpoint.
No request body ever reaches business logic without passing these.
"""

import re
from dataclasses import dataclass, field
from typing import Any

# ── Validation error ──────────────────────────────────────────────────────────
class ValidationError(Exception):
    def __init__(self, errors: dict[str, str]):
        self.errors = errors
        super().__init__(str(errors))


# ── Helpers ───────────────────────────────────────────────────────────────────
EMAIL_RE    = re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")
STORE_IDS   = {"aldi", "lidl", "rewe", "kaufland", "netto"}
LIST_STATUS = {"active", "completed", "archived"}


def _require(data: dict, key: str, label: str) -> Any:
    val = data.get(key)
    if val is None or (isinstance(val, str) and not val.strip()):
        raise ValidationError({key: f"{label} zorunludur"})
    return val


def _str(data: dict, key: str, label: str, min_len=1, max_len=255) -> str:
    val = str(_require(data, key, label)).strip()
    if len(val) < min_len:
        raise ValidationError({key: f"{label} en az {min_len} karakter olmalı"})
    if len(val) > max_len:
        raise ValidationError({key: f"{label} en fazla {max_len} karakter olabilir"})
    return val


def _int(data: dict, key: str, label: str, min_val=1, max_val=999) -> int:
    raw = _require(data, key, label)
    try:
        val = int(raw)
    except (ValueError, TypeError):
        raise ValidationError({key: f"{label} tam sayı olmalı"})
    if val < min_val or val > max_val:
        raise ValidationError({key: f"{label} {min_val}–{max_val} arasında olmalı"})
    return val


def _float(data: dict, key: str, label: str, min_val=0.0) -> float:
    raw = _require(data, key, label)
    try:
        val = float(raw)
    except (ValueError, TypeError):
        raise ValidationError({key: f"{label} sayı olmalı"})
    if val < min_val:
        raise ValidationError({key: f"{label} {min_val}'dan büyük olmalı"})
    return val


# ── Schema functions (return clean dict or raise ValidationError) ──────────────

def validate_register(data: dict) -> dict:
    errors: dict[str, str] = {}

    # name
    name = data.get("name", "")
    if not str(name).strip():
        errors["name"] = "Ad zorunludur"
    elif len(str(name).strip()) > 100:
        errors["name"] = "Ad en fazla 100 karakter olabilir"

    # email
    email = str(data.get("email", "")).strip().lower()
    if not email:
        errors["email"] = "E-posta zorunludur"
    elif not EMAIL_RE.match(email):
        errors["email"] = "Geçerli bir e-posta adresi girin"

    # password
    pw = str(data.get("password", ""))
    if not pw:
        errors["password"] = "Şifre zorunludur"
    elif len(pw) < 8:
        errors["password"] = "Şifre en az 8 karakter olmalı"
    elif len(pw) > 128:
        errors["password"] = "Şifre çok uzun"

    if errors:
        raise ValidationError(errors)

    return {
        "name":     str(name).strip(),
        "email":    email,
        "password": pw,
    }


def validate_login(data: dict) -> dict:
    errors: dict[str, str] = {}

    email = str(data.get("email", "")).strip().lower()
    if not email:
        errors["email"] = "E-posta zorunludur"
    elif not EMAIL_RE.match(email):
        errors["email"] = "Geçerli bir e-posta adresi girin"

    pw = str(data.get("password", ""))
    if not pw:
        errors["password"] = "Şifre zorunludur"

    if errors:
        raise ValidationError(errors)

    return {"email": email, "password": pw}


def validate_create_list(data: dict) -> dict:
    title = str(data.get("title", "Meine Liste")).strip()
    if not title:
        title = "Meine Liste"
    if len(title) > 100:
        raise ValidationError({"title": "Başlık en fazla 100 karakter olabilir"})
    return {"title": title}


def validate_add_item(data: dict) -> dict:
    errors: dict[str, str] = {}
    try:
        product_id = _str(data, "product_id", "Ürün ID")
    except ValidationError as e:
        errors.update(e.errors)
    try:
        name = _str(data, "name", "Ürün adı", max_len=200)
    except ValidationError as e:
        errors.update(e.errors)
    try:
        qty = _int(data, "qty", "Miktar", min_val=1, max_val=99)
    except ValidationError as e:
        errors.update(e.errors)

    icon = str(data.get("icon", "🛒"))[:8]
    unit = str(data.get("unit", "Stk"))[:20]

    if errors:
        raise ValidationError(errors)

    return {
        "product_id": product_id,
        "name":       name,
        "qty":        qty,
        "icon":       icon,
        "unit":       unit,
    }


def validate_basket_item(data: dict) -> dict:
    errors: dict[str, str] = {}
    try:
        product_id = _str(data, "product_id", "Ürün ID")
    except ValidationError as e:
        errors.update(e.errors)
    try:
        name = _str(data, "name", "Ürün adı", max_len=200)
    except ValidationError as e:
        errors.update(e.errors)
    try:
        qty = _int(data, "qty", "Miktar", min_val=1, max_val=99)
    except ValidationError as e:
        errors.update(e.errors)
    try:
        price = _float(data, "price", "Fiyat", min_val=0.01)
    except ValidationError as e:
        errors.update(e.errors)

    store_id = str(data.get("store_id", "")).strip().lower()
    if not store_id:
        errors["store_id"] = "Mağaza ID zorunludur"
    elif store_id not in STORE_IDS:
        errors["store_id"] = f"Geçersiz mağaza. Geçerli değerler: {', '.join(sorted(STORE_IDS))}"

    list_id = data.get("list_id")

    if errors:
        raise ValidationError(errors)

    return {
        "product_id": product_id,
        "name":       name,
        "qty":        qty,
        "price":      price,
        "store_id":   store_id,
        "list_id":    int(list_id) if list_id else None,
    }


def validate_save_template(data: dict) -> dict:
    title = str(data.get("title", "")).strip()
    if not title:
        raise ValidationError({"title": "Şablon adı zorunludur"})
    if len(title) > 100:
        raise ValidationError({"title": "Şablon adı en fazla 100 karakter olabilir"})
    items = data.get("items", [])
    if not isinstance(items, list):
        raise ValidationError({"items": "items bir liste olmalı"})
    return {"title": title, "items": items}
