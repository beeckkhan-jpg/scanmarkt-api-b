"""
auth.py — JWT token creation/verification and password hashing.
Secrets come exclusively from environment variables.
"""

import os
import hashlib
import hmac
import secrets
import time
from functools import wraps
from flask import request, jsonify
import jwt

# ── Read secrets from env — NEVER hardcode ───────────────────────────────────
JWT_SECRET:     str = os.environ["JWT_SECRET"]       # raises if missing
JWT_ALGORITHM:  str = os.getenv("JWT_ALGORITHM", "HS256")
JWT_EXPIRES_H:  int = int(os.getenv("JWT_EXPIRES_HOURS", "24"))


# ── Password hashing (PBKDF2-HMAC-SHA256, no bcrypt needed) ──────────────────
ITERATIONS = 260_000   # OWASP 2024 recommendation
HASH_NAME   = "sha256"
SALT_BYTES  = 32


def hash_password(plain: str) -> str:
    """Return 'salt$hash' string safe to store in DB."""
    salt = secrets.token_hex(SALT_BYTES)
    dk   = hashlib.pbkdf2_hmac(HASH_NAME, plain.encode(), salt.encode(), ITERATIONS)
    return f"{salt}${dk.hex()}"


def verify_password(plain: str, stored: str) -> bool:
    """Constant-time comparison to prevent timing attacks."""
    try:
        salt, stored_hash = stored.split("$", 1)
    except ValueError:
        return False
    dk = hashlib.pbkdf2_hmac(HASH_NAME, plain.encode(), salt.encode(), ITERATIONS)
    return hmac.compare_digest(dk.hex(), stored_hash)


# ── JWT ───────────────────────────────────────────────────────────────────────
def create_token(user_id: int, email: str) -> str:
    payload = {
        "sub":   str(user_id),
        "email": email,
        "iat":   int(time.time()),
        "exp":   int(time.time()) + JWT_EXPIRES_H * 3600,
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_token(token: str) -> dict:
    """Raise jwt.PyJWTError on invalid/expired token."""
    return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])


# ── Route decorator ───────────────────────────────────────────────────────────
def require_auth(f):
    """Decorator: attach decoded user payload to request or return 401."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return jsonify({"error": "Yetkilendirme başlığı eksik"}), 401
        token = auth_header[7:]
        try:
            payload = decode_token(token)
        except jwt.ExpiredSignatureError:
            return jsonify({"error": "Token süresi dolmuş, lütfen tekrar giriş yapın"}), 401
        except jwt.PyJWTError as e:
            return jsonify({"error": f"Geçersiz token: {str(e)}"}), 401
        request.user_id    = int(payload["sub"])
        request.user_email = payload["email"]
        return f(*args, **kwargs)
    return wrapper
